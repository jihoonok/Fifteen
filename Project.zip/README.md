# Fifteen
CMSC389N group project<br /><br />


Agenda: <br />

Set up a timer for both games <br />
Pass time values to the scores database <br />
Make 2 scores database, 1 for 2048 and 1 for 15 puzzle <br />
insert image that player used into the database for 15 puzzle score db<br />
finish 2048 game (up and down, timer) <br />
finish 15 game (timer) <br />
add music option to 15 game and 2048 game <br />
Make scores table pretty <br />
